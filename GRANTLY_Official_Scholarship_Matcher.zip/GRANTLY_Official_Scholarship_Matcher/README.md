# GRANTLY — Official Scholarship Matcher

A React + Vite scholarship discovery prototype. It collects a student's own details, filters a curated catalog of real scholarship schemes, explains why each scheme may or may not match, and links to official sources.

## Run locally
1. Install Node.js LTS.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown in the terminal (usually http://localhost:5173).

## Important data / integration note
The National Scholarship Portal (NSP) provides official scheme listings and an eligibility feature at https://scholarships.gov.in/. This project links directly to official sources, but does **not** pretend that NSP has a public, unrestricted read API. The publicly documented NSP API material located during development describes data submission by participating ministries/departments, not a public catalogue API for third-party apps. Therefore the catalogue below is a small, transparent, manually curated starter set and not a live synchronized feed. Recheck every scheme's current notice and deadline on its official website before applying.

Eligibility results are indicative screening only, not an official decision. The app does not submit applications, verify documents, or guarantee funding. Amounts are shown only where a commonly published scheme amount is included and are marked for verification; amounts and rules can change by academic year.

## To connect a real data API later
Use an authorized official API or a provider that explicitly permits access. Put secret API keys in a backend environment variable (never in React/browser code), add a backend endpoint, and replace `src/scholarships.js` with data fetched from that endpoint. Do not scrape a portal or bypass login/CAPTCHA. Browser-only direct requests can also fail because of CORS.

## Included
- Blank first-time profile form (no prefilled student identity)
- Input validation
- Indicative matching with reasons and missing information
- Official-source links for each scheme
- Search and category filters
- Saved list and application tracker
- Local browser persistence
- Responsive layout and accessible form labels
