// Starter catalogue of real schemes. Always verify current rules and amounts at the linked official source.
export const officialSources = {
  nsp: "https://scholarships.gov.in/All-Scholarships",
  aicte: "https://www.aicte-india.org/",
  socialJustice: "https://socialjustice.gov.in/schemes",
  tribal: "https://tribal.nic.in/",
  ugc: "https://www.ugc.gov.in/"
};

export const scholarships = [
  {
    id: "pragati-degree",
    name: "AICTE Pragati Scholarship Scheme — Technical Degree",
    provider: "All India Council for Technical Education (AICTE)",
    category: "Women in STEM",
    amount: "₹50,000 per year (verify current notice)",
    amountValue: 50000,
    amountNote: "Published scheme amount; confirm current academic-year guidelines.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "Support scheme for eligible girl students pursuing technical degree studies.",
    rules: [
      { label: "Gender", key: "gender", test: p => p.gender === "Female", detail: "The scheme is for girl students." },
      { label: "Technical degree course", key: "course", test: p => ["B.E.", "B.Tech", "Other technical degree"].includes(p.course), detail: "Your course should be a technical degree covered by the scheme." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 800000, detail: "Check the current income ceiling in the official guidelines (catalogue screening uses ₹8 lakh)." }
    ]
  },
  {
    id: "saksham-degree",
    name: "AICTE Saksham Scholarship Scheme — Technical Degree",
    provider: "All India Council for Technical Education (AICTE)",
    category: "Disability support",
    amount: "₹50,000 per year (verify current notice)",
    amountValue: 50000,
    amountNote: "Published scheme amount; confirm current academic-year guidelines.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "Support scheme for eligible specially-abled students in technical degree programmes.",
    rules: [
      { label: "Technical degree course", key: "course", test: p => ["B.E.", "B.Tech", "Other technical degree"].includes(p.course), detail: "Your course should be a technical degree covered by the scheme." },
      { label: "Disability certificate", key: "disability", test: p => p.disability === "Yes", detail: "A qualifying disability and valid documentation are required; verify the current threshold and rules." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 800000, detail: "Check the current income ceiling in the official guidelines (catalogue screening uses ₹8 lakh)." }
    ]
  },
  {
    id: "swanath-degree",
    name: "AICTE Swanath Scholarship Scheme — Technical Degree",
    provider: "All India Council for Technical Education (AICTE)",
    category: "Special circumstances",
    amount: "₹50,000 per year (verify current notice)",
    amountValue: 50000,
    amountNote: "Published scheme amount; confirm current academic-year guidelines.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "A scheme for students who fall under specific eligible special-circumstance groups.",
    rules: [
      { label: "Technical degree course", key: "course", test: p => ["B.E.", "B.Tech", "Other technical degree"].includes(p.course), detail: "Your course should be a technical degree covered by the scheme." },
      { label: "Special circumstance", key: "specialCircumstance", test: p => p.specialCircumstance === "Yes", detail: "You must meet one of the scheme's defined special-circumstance categories. Confirm exact definitions in the official notice." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 800000, detail: "Check the current income ceiling in the official guidelines (catalogue screening uses ₹8 lakh)." }
    ]
  },
  {
    id: "csss",
    name: "PM-USP Central Sector Scheme of Scholarship for College and University Students",
    provider: "Department of Higher Education, Government of India",
    category: "Merit-based",
    amount: "See official scheme notice",
    amountValue: null,
    amountNote: "Amount depends on the current official scheme rules and study level; no estimate shown here.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "Merit-oriented scheme with conditions related to Class XII performance, course and other criteria.",
    rules: [
      { label: "Current undergraduate study", key: "course", test: p => ["B.E.", "B.Tech", "Other technical degree", "Arts", "Science", "Commerce", "Other undergraduate"].includes(p.course), detail: "Course and institution eligibility must match the current guidelines." },
      { label: "Academic marks", key: "marks", test: p => p.marks !== "" && Number(p.marks) >= 80, detail: "Screening uses 80% as a preliminary signal only. Official merit-list / board percentile conditions may differ; verify the scheme notice." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 450000, detail: "Screening uses ₹4.5 lakh as a preliminary ceiling; verify the current official notice." }
    ]
  },
  {
    id: "top-class-obc",
    name: "PM YASASVI — Top Class Education in College for OBC, EBC and DNT Students",
    provider: "Department of Social Justice and Empowerment",
    category: "Category-based",
    amount: "See official scheme notice",
    amountValue: null,
    amountNote: "Benefits vary by the scheme's approved components and current rules.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "A scheme for eligible OBC, EBC and DNT students in covered institutions.",
    rules: [
      { label: "Category", key: "category", test: p => ["OBC", "EBC", "DNT"].includes(p.category), detail: "This scheme is intended for eligible OBC, EBC or DNT students." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 250000, detail: "Screening uses ₹2.5 lakh as a preliminary ceiling; verify the current official notice." },
      { label: "College / institution", key: "institution", test: p => p.institution !== "", detail: "Only institutions covered by the scheme qualify; check the official list." }
    ]
  },
  {
    id: "post-matric-disability",
    name: "Post-Matric Scholarship for Students with Disabilities",
    provider: "Department of Empowerment of Persons with Disabilities",
    category: "Disability support",
    amount: "See official scheme notice",
    amountValue: null,
    amountNote: "Components and rates depend on the current official guidelines.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "Official scheme listing for eligible students with disabilities studying after matriculation.",
    rules: [
      { label: "Disability certificate", key: "disability", test: p => p.disability === "Yes", detail: "Qualifying disability and valid documents are required; verify current criteria." },
      { label: "Post-matric study", key: "course", test: p => p.course !== "", detail: "Your study level and institution must be covered by the current guidelines." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 250000, detail: "Screening uses ₹2.5 lakh as a preliminary ceiling; verify the current official notice." }
    ]
  },
  {
    id: "sc-top-class",
    name: "Central Sector Scholarship of Top Class Education for SC Students",
    provider: "Department of Social Justice and Empowerment",
    category: "Category-based",
    amount: "See official scheme notice",
    amountValue: null,
    amountNote: "Benefit components and caps must be checked in the current notice.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Official NSP scheme listing",
    summary: "A scheme for eligible SC students admitted to institutions covered by the scheme.",
    rules: [
      { label: "Category", key: "category", test: p => p.category === "SC", detail: "This scheme is for eligible SC students." },
      { label: "Family income", key: "income", test: p => p.annualIncome !== "" && Number(p.annualIncome) <= 800000, detail: "Screening uses ₹8 lakh as a preliminary ceiling; verify the current official notice." },
      { label: "College / institution", key: "institution", test: p => p.institution !== "", detail: "The institution must be on the scheme's current approved list." }
    ]
  },
  {
    id: "nsp-directory",
    name: "Explore all schemes on National Scholarship Portal",
    provider: "National Scholarship Portal (Government of India)",
    category: "All schemes",
    amount: "Varies by scheme",
    amountValue: null,
    amountNote: "Use the official portal's own scheme and eligibility pages for current information.",
    source: "https://scholarships.gov.in/All-Scholarships",
    sourceLabel: "Open official scheme directory",
    summary: "Search the official catalogue for central and state schemes beyond this starter set.",
    rules: []
  }
];

export const profileFields = [
  "name", "state", "course", "year", "marks", "annualIncome", "category", "gender",
  "disability", "specialCircumstance", "institution"
];