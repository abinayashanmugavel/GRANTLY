import React, { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Bookmark, BookmarkCheck, GraduationCap, Search, ShieldCheck, SlidersHorizontal, ExternalLink, CheckCircle2, CircleAlert, ClipboardList, UserRound, LayoutDashboard, BookOpen, Menu, X, Plus, Trash2 } from "lucide-react";
import { scholarships } from "./scholarships.js";

const emptyProfile = {
  name: "", state: "", course: "", year: "", marks: "", annualIncome: "",
  category: "", gender: "", disability: "", specialCircumstance: "", institution: ""
};
const readStore = (key, fallback) => {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
};
const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);

function evaluate(scholarship, profile) {
  if (!scholarship.rules.length) return { status: "directory", passed: [], failed: [], missing: [], score: 0 };
  const passed = [], failed = [], missing = [];
  for (const rule of scholarship.rules) {
    const required = rule.key === "income" ? profile.annualIncome !== "" :
      rule.key === "marks" ? profile.marks !== "" :
      rule.key === "institution" ? profile.institution.trim() !== "" :
      profile[rule.key] !== "";
    if (!required) missing.push(rule);
    else if (rule.test(profile)) passed.push(rule);
    else failed.push(rule);
  }
  const score = Math.round((passed.length / scholarship.rules.length) * 100);
  return { status: failed.length ? "not-match" : missing.length ? "needs-info" : "potential-match", passed, failed, missing, score };
}

function App() {
  const [profile, setProfile] = useState(() => readStore("grantly-profile-v2", emptyProfile));
  const [profileSaved, setProfileSaved] = useState(() => !!readStore("grantly-profile-v2", null)?.name);
  const [active, setActive] = useState("Dashboard");
  const [editing, setEditing] = useState(() => !readStore("grantly-profile-v2", null)?.name);
  const [saved, setSaved] = useState(() => readStore("grantly-saved-v2", []));
  const [tracker, setTracker] = useState(() => readStore("grantly-tracker-v2", []));
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All categories");
  const [mobileNav, setMobileNav] = useState(false);
  const [notice, setNotice] = useState("");
  useEffect(() => localStorage.setItem("grantly-profile-v2", JSON.stringify(profile)), [profile]);
  useEffect(() => localStorage.setItem("grantly-saved-v2", JSON.stringify(saved)), [saved]);
  useEffect(() => localStorage.setItem("grantly-tracker-v2", JSON.stringify(tracker)), [tracker]);

  const results = useMemo(() => scholarships.map(s => ({ ...s, evaluation: evaluate(s, profile) }))
    .filter(s => !search || `${s.name} ${s.provider} ${s.category}`.toLowerCase().includes(search.toLowerCase()))
    .filter(s => category === "All categories" || s.category === category)
    .sort((a,b) => {
      const rank = x => x.evaluation.status === "potential-match" ? 0 : x.evaluation.status === "needs-info" ? 1 : x.evaluation.status === "directory" ? 2 : 3;
      return rank(a)-rank(b) || b.evaluation.score-a.evaluation.score;
    }), [profile, search, category]);

  const matched = scholarships.map(s => ({ ...s, evaluation: evaluate(s, profile) })).filter(s => ["potential-match","needs-info"].includes(s.evaluation.status) && s.rules.length);
  const listedValue = matched.reduce((sum, s) => sum + (s.amountValue || 0), 0);
  const update = e => setProfile(p => ({ ...p, [e.target.name]: e.target.value }));
  const saveProfile = e => {
    e.preventDefault();
    if (!profile.name.trim() || !profile.state || !profile.course || !profile.year || profile.marks === "" || profile.annualIncome === "" || !profile.category || !profile.gender || !profile.disability || !profile.specialCircumstance || !profile.institution.trim()) {
      setNotice("Please complete every field so the eligibility screening can work better."); return;
    }
    if (Number(profile.marks) < 0 || Number(profile.marks) > 100 || Number(profile.annualIncome) < 0) {
      setNotice("Please enter valid marks (0–100) and a non-negative annual family income."); return;
    }
    setProfileSaved(true); setEditing(false); setActive("Dashboard"); setNotice("Profile saved. Scholarship screening updated from your details.");
  };
  const toggleSaved = id => setSaved(v => v.includes(id) ? v.filter(x => x !== id) : [...v, id]);
  const addTracker = s => {
    if (tracker.some(t => t.id === s.id)) { setNotice("This scheme is already in your tracker."); return; }
    setTracker(v => [...v, { id: s.id, name: s.name, status: "Interested", updatedAt: new Date().toISOString() }]);
    setNotice("Added to your application tracker.");
  };
  const changeTracker = (id, status) => setTracker(v => v.map(t => t.id === id ? { ...t, status, updatedAt: new Date().toISOString() } : t));
  const removeTracker = id => setTracker(v => v.filter(t => t.id !== id));
  const byId = id => scholarships.find(s => s.id === id);
  const visibleList = active === "Saved scholarships" ? scholarships.filter(s => saved.includes(s.id)).map(s => ({...s, evaluation:evaluate(s,profile)})) :
    active === "Discover scholarships" ? results :
    active === "Dashboard" ? results.filter(s => ["potential-match","needs-info"].includes(s.evaluation.status) && s.rules.length).slice(0,4) : results;

  const nav = [
    { label: "Dashboard", icon: LayoutDashboard },
    { label: "Discover scholarships", icon: BookOpen },
    { label: "Saved scholarships", icon: Bookmark },
    { label: "Application tracker", icon: ClipboardList },
    { label: "My profile", icon: UserRound }
  ];
  const title = active === "Dashboard" ? "Your scholarship workspace" : active;
  const showProfile = active === "My profile" || editing;
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><GraduationCap size={22}/></div><div><b>GRANTLY</b><small>STUDENT WORKSPACE</small></div><button className="mobile-close" onClick={()=>setMobileNav(false)} aria-label="Close menu"><X size={18}/></button></div>
      <div className="nav-caption">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.label} className={`nav-item ${active===item.label ? "active":""}`} onClick={()=>{setActive(item.label);setEditing(item.label==="My profile" && !profileSaved);setMobileNav(false);setNotice("");}}><item.icon size={18}/><span>{item.label}</span>{item.label==="Saved scholarships" && saved.length>0 && <em>{saved.length}</em>}</button>)}</nav>
      <div className="sidebar-bottom"><ShieldCheck size={17}/><span>Official-source-first discovery</span></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main">
      <header className="topbar"><button className="menu-toggle" onClick={()=>setMobileNav(true)} aria-label="Open menu"><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{active}</b></div><div className="profile-pill"><div className="avatar">{profile.name ? profile.name.trim().charAt(0).toUpperCase() : "?"}</div><div><b>{profile.name || "Profile not set up"}</b><small>{profile.course ? `${profile.course} · Year ${profile.year || "—"}` : "Add your student details"}</small></div></div></header>
      <div className="content">
        {notice && <div className="notice" role="status"><CheckCircle2 size={17}/>{notice}<button onClick={()=>setNotice("")} aria-label="Dismiss notice"><X size={15}/></button></div>}
        {showProfile ? <section className="panel profile-panel">
          <div className="section-eyebrow">PERSONALIZED SCREENING</div><h1>{profileSaved ? "Edit your profile" : "Build your student profile"}</h1>
          <p className="muted">Enter your own information. These details stay in this browser in this demo; they are not sent to scholarship portals.</p>
          <form onSubmit={saveProfile} className="profile-form">
            <div className="field"><label htmlFor="name">Full name *</label><input id="name" name="name" value={profile.name} onChange={update} required placeholder="Enter your full name"/></div>
            <div className="field"><label htmlFor="state">Domicile state/UT *</label><select id="state" name="state" value={profile.state} onChange={update} required><option value="">Select state/UT</option>{["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Delhi","Jammu and Kashmir","Ladakh","Puducherry","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label htmlFor="course">Current course *</label><select id="course" name="course" value={profile.course} onChange={update} required><option value="">Select course</option>{["B.E.","B.Tech","Other technical degree","Technical diploma","Arts","Science","Commerce","Other undergraduate","Postgraduate","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label htmlFor="year">Current year of study *</label><select id="year" name="year" value={profile.year} onChange={update} required><option value="">Select year</option>{["1","2","3","4","5","Final year","Other"].map(x=><option key={x} value={x}>{x==="Final year" ? x : `Year ${x}`}</option>)}</select></div>
            <div className="field"><label htmlFor="marks">Previous qualifying exam marks (%) *</label><input id="marks" name="marks" type="number" min="0" max="100" step="0.01" value={profile.marks} onChange={update} required placeholder="e.g. 82.5"/></div>
            <div className="field"><label htmlFor="annualIncome">Annual family income (₹) *</label><input id="annualIncome" name="annualIncome" type="number" min="0" value={profile.annualIncome} onChange={update} required placeholder="e.g. 250000"/></div>
            <div className="field"><label htmlFor="category">Social category *</label><select id="category" name="category" value={profile.category} onChange={update} required><option value="">Select category</option>{["General","EWS","OBC","EBC","DNT","SC","ST","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label htmlFor="gender">Gender (for scheme rules) *</label><select id="gender" name="gender" value={profile.gender} onChange={update} required><option value="">Select option</option>{["Female","Male","Prefer not to say","Other"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label htmlFor="disability">Do you have a qualifying disability? *</label><select id="disability" name="disability" value={profile.disability} onChange={update} required><option value="">Select option</option>{["Yes","No","Not sure"].map(x=><option key={x}>{x}</option>)}</select></div>
            <div className="field"><label htmlFor="specialCircumstance">Do you fall under a special-circumstance category covered by Swanath? *</label><select id="specialCircumstance" name="specialCircumstance" value={profile.specialCircumstance} onChange={update} required><option value="">Select option</option>{["Yes","No","Not sure"].map(x=><option key={x}>{x}</option>)}</select><small>Check the official notice for the exact categories.</small></div>
            <div className="field full"><label htmlFor="institution">College / institution name *</label><input id="institution" name="institution" value={profile.institution} onChange={update} required placeholder="Enter your college name"/></div>
            <div className="form-footer"><p><ShieldCheck size={16}/> Never enter Aadhaar, bank account, passwords or OTPs here.</p><button className="primary" type="submit">Save profile & check matches <ArrowUpRight size={17}/></button></div>
          </form>
        </section> : <>
          <section className="hero">
            <div><div className="section-eyebrow">YOUR SCHOLARSHIP OVERVIEW</div><h1>{profileSaved ? `Welcome${profile.name ? `, ${profile.name.split(" ")[0]}` : " back"} ✦` : "Find scholarships that fit you ✦"}</h1><p>{profileSaved ? "We screen the catalogue against the details you entered. Review the reasons and confirm the official rules before applying." : "Start by entering your student details to see an indicative eligibility screen."}</p></div>
            <button className="secondary" onClick={()=>{setActive("My profile");setEditing(true);}}><UserRound size={16}/> {profileSaved ? "Edit profile" : "Set up profile"}</button>
          </section>
          {active==="Dashboard" && <div className="stats-grid">
            <div className="stat-card"><div className="stat-icon purple"><BookOpen size={18}/></div><div><small>Potential / needs info</small><strong>{profileSaved ? matched.length : "—"}</strong><span>Not official approval</span></div></div>
            <div className="stat-card"><div className="stat-icon blue"><Bookmark size={18}/></div><div><small>Saved schemes</small><strong>{saved.length}</strong><span>Your shortlist</span></div></div>
            <div className="stat-card"><div className="stat-icon orange"><ClipboardList size={18}/></div><div><small>In your tracker</small><strong>{tracker.length}</strong><span>Application progress</span></div></div>
            <div className="stat-card"><div className="stat-icon green"><ShieldCheck size={18}/></div><div><small>Indicative listed value</small><strong>{profileSaved && listedValue ? money(listedValue) : "Not estimated"}</strong><span>Known amounts only; not a promise</span></div></div>
          </div>}
          {active==="Application tracker" ? <section className="panel"><div className="section-heading"><div><div className="section-eyebrow">YOUR PROGRESS</div><h2>Application tracker</h2><p className="muted">Tracking here does not submit an application to the government portal.</p></div></div>{tracker.length===0 ? <Empty title="Nothing tracked yet" body="Open a scholarship and add it to your tracker to keep its status here."/> : <div className="tracker-list">{tracker.map(t=><div className="tracker-row" key={t.id}><div className="scheme-mini"><div className="scheme-logo"><GraduationCap/></div><div><b>{t.name}</b><small>{byId(t.id)?.provider}</small></div></div><select aria-label={`Status for ${t.name}`} value={t.status} onChange={e=>changeTracker(t.id,e.target.value)}>{["Interested","Checking eligibility","Preparing documents","Applied on official portal","Awaiting result","Awarded","Not eligible","Closed"].map(s=><option key={s}>{s}</option>)}</select><button className="icon-btn danger" onClick={()=>removeTracker(t.id)} aria-label={`Remove ${t.name}`}><Trash2 size={17}/></button></div>)}</div>}</section> :
          active==="My profile" ? <section className="panel"><h2>Your saved details</h2><p className="muted">These are the details currently used for screening.</p><div className="profile-summary">{Object.entries({Name:profile.name,State:profile.state,Course:profile.course,Year:profile.year,Marks:`${profile.marks}%`, "Annual family income":profile.annualIncome ? money(Number(profile.annualIncome)):"",Category:profile.category,Gender:profile.gender,Disability:profile.disability,"Special circumstance":profile.specialCircumstance,Institution:profile.institution}).map(([k,v])=><div key={k}><small>{k}</small><b>{v || "Not entered"}</b></div>)}</div><button className="primary" onClick={()=>setEditing(true)}>Edit details</button></section> :
          <section className="panel">
            <div className="section-heading"><div><div className="section-eyebrow">{active==="Saved scholarships" ? "YOUR SHORTLIST" : active==="Dashboard" ? "BASED ON YOUR PROFILE" : "OFFICIAL-SOURCE CATALOGUE"}</div><h2>{active==="Dashboard" ? "Potential matches to review" : active==="Saved scholarships" ? "Saved scholarships" : "Discover scholarships"}</h2><p className="muted">{active==="Dashboard" ? "Potential matches are screening results, not official eligibility decisions." : "Each result links to an official source. Confirm current-year rules, deadlines and amount there."}</p></div>{active==="Dashboard" && <button className="text-button" onClick={()=>setActive("Discover scholarships")}>View all <ArrowUpRight size={15}/></button>}</div>
            {active!=="Dashboard" && <div className="toolbar"><div className="search-box"><Search size={17}/><input aria-label="Search scholarships" placeholder="Search scheme, provider, category..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="filter-box"><SlidersHorizontal size={16}/><select aria-label="Filter category" value={category} onChange={e=>setCategory(e.target.value)}>{["All categories",...new Set(scholarships.map(s=>s.category))].map(c=><option key={c}>{c}</option>)}</select></div></div>}
            {!profileSaved && active!=="Saved scholarships" && <div className="callout"><CircleAlert size={18}/><div><b>Set up your profile first</b><p>Results are not personalized until you complete your profile.</p></div><button onClick={()=>{setActive("My profile");setEditing(true);}}>Add details</button></div>}
            {visibleList.length===0 ? <Empty title={active==="Saved scholarships" ? "No saved schemes yet" : "No schemes found"} body={active==="Saved scholarships" ? "Save a scheme from Discover scholarships to see it here." : "Try a different search or category, or review all official schemes."}/> :
              <div className="scholarship-grid">{visibleList.map(s=><ScholarshipCard key={s.id} item={s} saved={saved.includes(s.id)} inTracker={tracker.some(t=>t.id===s.id)} profileSaved={profileSaved} onSave={()=>toggleSaved(s.id)} onTrack={()=>addTracker(s)}/>)}</div>}
          </section>}
          <section className="disclaimer"><ShieldCheck size={19}/><div><b>Official-source-first. No false guarantees.</b><p>GRANTLY uses a starter catalogue and indicative rule checks. It is not a live feed from the government portal, and it cannot confirm approval. The official portal has the final eligibility rules and deadlines.</p><a href="https://scholarships.gov.in/All-Scholarships" target="_blank" rel="noreferrer">Open National Scholarship Portal <ExternalLink size={13}/></a></div></section>
        </>}
        <footer>GRANTLY · Scholarship discovery workspace <span>Demo prototype · Verify every scheme officially</span></footer>
      </div>
    </main>
  </div>;
}

function ScholarshipCard({item:s, saved, inTracker, profileSaved, onSave, onTrack}) {
  const e = s.evaluation;
  const status = e.status === "potential-match" ? ["Potential match","match"] : e.status === "needs-info" ? ["More information needed","info"] : e.status === "not-match" ? ["Criteria not met","no-match"] : ["Official directory","directory"];
  return <article className="scholarship-card">
    <div className="card-top"><div className="scheme-logo"><GraduationCap size={21}/></div><button className={`icon-btn ${saved?"saved":""}`} onClick={onSave} aria-label={saved ? "Remove from saved" : "Save scholarship"} title={saved ? "Remove from saved" : "Save scholarship"}>{saved?<BookmarkCheck size={19}/>:<Bookmark size={19}/>}</button></div>
    <div className="tag-row"><span className="tag">{s.category}</span><span className={`status ${status[1]}`}>{status[0]}</span></div>
    <h3>{s.name}</h3><p className="provider">{s.provider}</p><p className="summary">{s.summary}</p>
    <div className="amount-block"><small>Listed benefit</small><strong>{s.amount}</strong><span>{s.amountNote}</span></div>
    {profileSaved && s.rules.length>0 && <div className="criteria"><b>Screening details</b>{e.passed.slice(0,2).map(r=><div className="criteria-line good" key={r.key}><CheckCircle2 size={14}/><span>{r.label} — matches preliminary rule</span></div>)}{e.missing.slice(0,2).map(r=><div className="criteria-line warn" key={r.key}><CircleAlert size={14}/><span>{r.label} — more information needed</span></div>)}{e.failed.slice(0,2).map(r=><div className="criteria-line bad" key={r.key}><X size={14}/><span>{r.label} — current entry does not match preliminary rule</span></div>)}{e.passed.length+e.missing.length+e.failed.length===0 && <span className="muted">Open the official scheme rules.</span>}</div>}
    <div className="card-actions"><a className="primary-link" href={s.source} target="_blank" rel="noreferrer">Official details <ArrowUpRight size={15}/></a><button className="secondary small" onClick={onTrack} disabled={inTracker}>{inTracker ? "In tracker" : "Track"} <Plus size={14}/></button></div>
    <small className="source-label"><ExternalLink size={12}/>{s.sourceLabel}</small>
  </article>;
}
function Empty({title,body}) { return <div className="empty-state"><div className="empty-icon"><BookOpen size={22}/></div><b>{title}</b><p>{body}</p></div>; }

export default App;